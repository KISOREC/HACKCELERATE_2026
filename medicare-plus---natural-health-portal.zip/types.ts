
export type UserRole = 'ADMIN' | 'DOCTOR' | 'CLIENT';

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  fullName: string;
}

export interface ClientReport {
  id: string;
  clientId: string;
  doctorName: string;
  clientName: string;
  age: number;
  disease: string;
  fee: number;
  date: string;
}

export interface ClientMedicine {
  id: string;
  clientId: string;
  doctorName: string;
  tabletDetails: string;
  schedule: string; // Time to eat
  date: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
