import React from 'react';
import { User, ClientReport, ClientMedicine } from '../types';
import { db } from '../services/database';

interface ClientDashboardProps {
  user: User;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const ClientDashboard: React.FC<ClientDashboardProps> = ({ user, onLogout, isDarkMode, toggleTheme }) => {
  const myReports = db.getReports().filter(r => r.clientId === user.id);
  const myMedicines = db.getMedicines().filter(m => m.clientId === user.id);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'bg-stone-950 text-white' : 'bg-stone-50 text-stone-900'}`}>
      <nav className={`border-b px-8 py-5 flex justify-between items-center sticky top-0 z-20 backdrop-blur-md transition-all ${isDarkMode ? 'bg-stone-900/80 border-stone-800' : 'bg-white/80 border-stone-200'}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-red-600 rounded-2xl flex items-center justify-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
          </div>
          <div className={`font-black text-2xl tracking-tight transition-colors ${isDarkMode ? 'text-red-400' : 'text-red-800'}`}>MEDICARE<span className={`ml-1 font-medium ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>PLUS</span></div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className={`p-2.5 rounded-xl border transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-red-400 hover:bg-stone-700' : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-stone-200'}`}
          >
            {isDarkMode ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg> : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>}
          </button>
          <div className="text-right hidden sm:block">
            <p className={`text-[10px] font-bold uppercase tracking-widest ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>Patient Portal</p>
            <p className={`text-sm font-bold ${isDarkMode ? 'text-stone-200' : 'text-stone-700'}`}>{user.fullName}</p>
          </div>
          <button onClick={onLogout} className={`px-6 py-2.5 rounded-xl text-sm font-black tracking-tighter transition-all ${isDarkMode ? 'bg-stone-800 text-stone-300 hover:bg-red-900/20 hover:text-red-400' : 'bg-stone-100 text-stone-600 hover:bg-red-50 hover:text-red-600'}`}>Logout</button>
        </div>
      </nav>

      <main className="p-8 max-w-6xl mx-auto space-y-12">
        <header className="bg-red-800 p-12 rounded-[3.5rem] text-white shadow-2xl relative overflow-hidden flex flex-col items-start gap-4">
           <div className="absolute -top-10 -right-10 w-64 h-64 bg-red-700 rounded-full opacity-50 blur-3xl"></div>
           <div className="absolute top-10 right-10 opacity-10">
              <svg width="200" height="200" viewBox="0 0 24 24" fill="currentColor"><path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,11 17,8 17,8Z"/></svg>
           </div>
           <div className="px-4 py-1 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-[0.2em] border border-white/20">Member Dashboard</div>
           <h1 className="text-4xl md:text-5xl font-black leading-tight max-w-lg">Your Journey to Natural Wellness</h1>
           <p className="text-red-100 font-medium max-w-md opacity-80">Access your clinical logs and herbal prescriptions in a secure, digital environment designed for your comfort.</p>
        </header>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Medical Reports Section */}
          <section className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className={`text-2xl font-black flex items-center gap-3 ${isDarkMode ? 'text-red-400' : 'text-stone-800'}`}>
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${isDarkMode ? 'bg-stone-800 text-red-400' : 'bg-red-50 text-red-600'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/></svg>
                </div>
                Clinical Records
              </h2>
              <span className="text-[10px] font-black text-stone-500 uppercase tracking-widest">{myReports.length} Logs found</span>
            </div>
            <div className="space-y-6">
              {myReports.length === 0 ? (
                <div className={`border-2 border-dashed p-16 rounded-[2.5rem] text-center transition-all ${isDarkMode ? 'bg-stone-900/50 border-stone-800' : 'bg-white border-stone-200'}`}>
                   <p className="text-stone-500 font-bold uppercase tracking-widest">No clinical history recorded.</p>
                </div>
              ) : (
                myReports.map(report => (
                  <div key={report.id} className={`p-8 rounded-[2.5rem] border shadow-sm transition-all group ${isDarkMode ? 'bg-stone-900 border-stone-800 hover:border-red-600/50' : 'bg-white border-stone-100 hover:shadow-2xl hover:shadow-red-900/5'}`}>
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <h3 className={`font-extrabold text-2xl transition-colors ${isDarkMode ? 'text-stone-100 group-hover:text-red-400' : 'text-stone-800 group-hover:text-red-600'}`}>{report.disease}</h3>
                        <p className={`text-xs font-bold mt-1 uppercase tracking-tighter italic ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>Verified by {report.doctorName}</p>
                      </div>
                      <div className={`px-4 py-2 rounded-2xl text-[10px] font-black border uppercase tracking-widest ${isDarkMode ? 'bg-stone-800 border-stone-700 text-stone-400' : 'bg-stone-50 border-stone-100 text-stone-500'}`}>{report.date}</div>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      <div className={`px-5 py-3 rounded-2xl border ${isDarkMode ? 'bg-stone-950 border-stone-800' : 'bg-stone-50 border-stone-100'}`}>
                         <p className="text-[10px] font-black text-stone-500 uppercase tracking-widest">Patient Age</p>
                         <p className={`text-lg font-black ${isDarkMode ? 'text-stone-200' : 'text-stone-800'}`}>{report.age}</p>
                      </div>
                      <div className={`px-5 py-3 rounded-2xl border ${isDarkMode ? 'bg-red-950/20 border-red-900/30' : 'bg-red-50/50 border-red-100/50'}`}>
                         <p className="text-[10px] font-black text-red-500 uppercase tracking-widest">Consultation Fee</p>
                         <p className="text-lg font-black text-red-600">${report.fee}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* Medicines Section */}
          <section className="space-y-6">
             <div className="flex items-center justify-between">
              <h2 className={`text-2xl font-black flex items-center gap-3 ${isDarkMode ? 'text-red-400' : 'text-red-900'}`}>
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${isDarkMode ? 'bg-stone-800 text-red-400' : 'bg-red-50 text-red-600'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>
                </div>
                Active Prescriptions
              </h2>
            </div>
            <div className="space-y-6">
               {myMedicines.length === 0 ? (
                <div className={`border-2 border-dashed p-16 rounded-[2.5rem] text-center transition-all ${isDarkMode ? 'bg-stone-900/50 border-stone-800' : 'bg-white border-stone-200'}`}>
                   <p className="text-stone-500 font-bold uppercase tracking-widest">No medications prescribed.</p>
                </div>
              ) : (
                myMedicines.map(med => (
                  <div key={med.id} className={`p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden transition-all ${isDarkMode ? 'bg-stone-900 border border-stone-800' : 'bg-stone-900 text-stone-100'}`}>
                    <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-2xl"></div>
                    <div className="flex justify-between items-center mb-8">
                       <span className="text-[10px] font-black text-red-400 uppercase tracking-[0.2em] border border-red-400/20 px-3 py-1 rounded-full">Medical Order</span>
                       <span className="text-[10px] font-bold text-stone-500 tracking-widest">{med.date}</span>
                    </div>
                    <div className={`mb-8 whitespace-pre-wrap font-bold text-xl leading-relaxed italic font-serif ${isDarkMode ? 'text-stone-200' : 'text-stone-100'}`}>
                      "{med.tabletDetails}"
                    </div>
                    <div className={`flex items-center gap-3 p-4 rounded-2xl border ${isDarkMode ? 'bg-stone-800 border-stone-700' : 'bg-white/5 border-white/10'}`}>
                       <div className="w-8 h-8 bg-red-500 rounded-xl flex items-center justify-center text-white">
                         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                       </div>
                       <div>
                         <p className="text-[10px] font-black text-stone-500 uppercase tracking-widest">Guideline</p>
                         <p className="text-sm font-black text-red-400">{med.schedule}</p>
                       </div>
                    </div>
                    <p className="mt-8 text-[9px] text-stone-500 font-bold tracking-widest uppercase text-center border-t border-white/5 pt-4">Digitally authenticated by Dr. {med.doctorName}</p>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default ClientDashboard;