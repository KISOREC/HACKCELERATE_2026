import React, { useState } from 'react';
import { User, ClientReport, ClientMedicine } from '../types';
import { db } from '../services/database';

interface DoctorDashboardProps {
  user: User;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const DoctorDashboard: React.FC<DoctorDashboardProps> = ({ user, onLogout, isDarkMode, toggleTheme }) => {
  const [activeTab, setActiveTab] = useState<'clients' | 'report' | 'medicine'>('clients');
  const [showAddClient, setShowAddClient] = useState(false);
  const [newClient, setNewClient] = useState({ username: '', password: '', fullName: '' });
  
  const [reportForm, setReportForm] = useState({ clientUser: '', age: '', disease: '', fee: '' });
  const [medicineForm, setMedicineForm] = useState({ clientUser: '', details: '', schedule: '' });

  const clients = db.getUsers().filter(u => u.role === 'CLIENT');

  const handleAddClient = (e: React.FormEvent) => {
    e.preventDefault();
    db.saveUser({
      id: Math.random().toString(36).substr(2, 9),
      username: newClient.username,
      password: newClient.password,
      fullName: newClient.fullName,
      role: 'CLIENT'
    });
    setShowAddClient(false);
    setNewClient({ username: '', password: '', fullName: '' });
  };

  const handleSaveReport = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.username === reportForm.clientUser);
    if (!client) return alert('Select a valid patient');

    db.saveReport({
      id: Math.random().toString(36).substr(2, 9),
      clientId: client.id,
      clientName: client.fullName,
      doctorName: user.fullName,
      age: parseInt(reportForm.age),
      disease: reportForm.disease,
      fee: parseFloat(reportForm.fee),
      date: new Date().toLocaleDateString()
    });
    alert('Report safely stored.');
    setReportForm({ clientUser: '', age: '', disease: '', fee: '' });
  };

  const handleSaveMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.username === medicineForm.clientUser);
    if (!client) return alert('Select a valid patient');

    db.saveMedicine({
      id: Math.random().toString(36).substr(2, 9),
      clientId: client.id,
      doctorName: user.fullName,
      tabletDetails: medicineForm.details,
      schedule: medicineForm.schedule,
      date: new Date().toLocaleDateString()
    });
    alert('Prescription successfully registered.');
    setMedicineForm({ clientUser: '', details: '', schedule: '' });
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'bg-stone-950 text-white' : 'bg-stone-50 text-stone-900'}`}>
      <nav className={`border-b px-8 py-5 flex justify-between items-center sticky top-0 z-20 backdrop-blur-md transition-all ${isDarkMode ? 'bg-stone-900/80 border-stone-800' : 'bg-white/80 border-stone-200'}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-red-600 rounded-2xl flex items-center justify-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
          </div>
          <div className={`font-black text-2xl tracking-tight transition-colors ${isDarkMode ? 'text-red-400' : 'text-red-800'}`}>MEDICARE<span className={`ml-1 font-medium ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>Doc</span></div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className={`p-2.5 rounded-xl border transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-red-400 hover:bg-stone-700' : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-stone-200'}`}
          >
            {isDarkMode ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg> : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>}
          </button>
          <div className="text-right">
            <p className={`text-[10px] font-bold uppercase tracking-widest ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>Practitioner</p>
            <p className={`text-sm font-bold ${isDarkMode ? 'text-stone-200' : 'text-stone-700'}`}>Dr. {user.fullName}</p>
          </div>
          <button onClick={onLogout} className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all border ${isDarkMode ? 'bg-stone-800 border-stone-700 text-stone-300 hover:bg-red-900/20 hover:text-red-400' : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-red-50 hover:text-red-600'}`}>Logout</button>
        </div>
      </nav>

      <main className="p-8 max-w-6xl mx-auto">
        <div className="flex flex-wrap gap-4 mb-10">
          <button onClick={() => setActiveTab('clients')} className={`px-8 py-3 rounded-2xl text-xs font-black tracking-widest uppercase transition-all ${activeTab === 'clients' ? 'bg-red-600 text-white shadow-xl shadow-red-200' : (isDarkMode ? 'bg-stone-900 border-2 border-stone-800 text-stone-500 hover:text-stone-300' : 'bg-white border-2 border-stone-100 text-stone-500 hover:bg-stone-50')}`}>Patient Directory</button>
          <button onClick={() => setActiveTab('report')} className={`px-8 py-3 rounded-2xl text-xs font-black tracking-widest uppercase transition-all ${activeTab === 'report' ? 'bg-red-600 text-white shadow-xl shadow-red-200' : (isDarkMode ? 'bg-stone-900 border-2 border-stone-800 text-stone-500 hover:text-stone-300' : 'bg-white border-2 border-stone-100 text-stone-500 hover:bg-stone-50')}`}>Health Log</button>
          <button onClick={() => setActiveTab('medicine')} className={`px-8 py-3 rounded-2xl text-xs font-black tracking-widest uppercase transition-all ${activeTab === 'medicine' ? 'bg-red-600 text-white shadow-xl shadow-red-200' : (isDarkMode ? 'bg-stone-900 border-2 border-stone-800 text-stone-500 hover:text-stone-300' : 'bg-white border-2 border-stone-100 text-stone-500 hover:bg-stone-50')}`}>Prescriptions</button>
        </div>

        {activeTab === 'clients' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-5 duration-500">
             <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <h2 className={`text-3xl font-extrabold ${isDarkMode ? 'text-white' : 'text-stone-800'}`}>My Patients</h2>
              <button 
                onClick={() => setShowAddClient(true)}
                className="bg-red-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-red-700 transition-all shadow-xl shadow-red-200 flex items-center gap-3"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/></svg>
                Register Patient
              </button>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {clients.length === 0 ? (
                <div className={`col-span-full py-20 rounded-[3rem] border-2 border-dashed text-center transition-all ${isDarkMode ? 'bg-stone-900/50 border-stone-800' : 'bg-white border-stone-200'}`}>
                  <p className="text-stone-500 font-bold uppercase tracking-widest">No patients registered yet</p>
                </div>
              ) : (
                clients.map(c => (
                  <div key={c.id} className={`p-8 rounded-[2.5rem] border shadow-sm transition-all text-center group ${isDarkMode ? 'bg-stone-900 border-stone-800 hover:border-red-600/50' : 'bg-white border-stone-100 hover:shadow-2xl hover:shadow-red-900/5'}`}>
                    <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-6 transition-all ${isDarkMode ? 'bg-stone-800 text-red-400 group-hover:bg-red-600 group-hover:text-white' : 'bg-red-50 text-red-600 group-hover:bg-red-600 group-hover:text-white'}`}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </div>
                    <h3 className={`font-extrabold text-xl ${isDarkMode ? 'text-stone-100' : 'text-stone-800'}`}>{c.fullName}</h3>
                    <p className={`text-xs font-bold mt-2 uppercase tracking-widest ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>Patient ID: {c.username}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {(activeTab === 'report' || activeTab === 'medicine') && (
          <div className={`p-10 rounded-[3rem] border shadow-2xl transition-all animate-in slide-in-from-bottom-5 duration-500 ${isDarkMode ? 'bg-stone-900 border-stone-800 shadow-stone-950/20' : 'bg-white border-stone-200 shadow-stone-900/5'}`}>
            <h2 className={`text-3xl font-extrabold mb-10 flex items-center gap-4 ${isDarkMode ? 'text-red-400' : 'text-stone-800'}`}>
               <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isDarkMode ? 'bg-stone-800 text-red-400' : 'bg-red-100 text-red-600'}`}>
                 {activeTab === 'report' ? (
                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
                 ) : (
                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>
                 )}
               </div>
               {activeTab === 'report' ? 'Insert Health Log' : 'Herbal & Clinical Prescriptions'}
            </h2>
            <form onSubmit={activeTab === 'report' ? handleSaveReport : handleSaveMedicine} className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className={`block text-sm font-black uppercase tracking-widest ml-1 ${isDarkMode ? 'text-stone-500' : 'text-stone-500'}`}>Target Patient</label>
                  <select 
                    className={`w-full border-2 rounded-2xl p-4 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:bg-white focus:border-red-500'}`} 
                    value={activeTab === 'report' ? reportForm.clientUser : medicineForm.clientUser} 
                    onChange={e => activeTab === 'report' ? setReportForm({...reportForm, clientUser: e.target.value}) : setMedicineForm({...medicineForm, clientUser: e.target.value})}
                    required
                  >
                    <option value="">-- Choose Profile --</option>
                    {clients.map(c => <option key={c.id} value={c.username}>{c.fullName}</option>)}
                  </select>
                </div>
                {activeTab === 'report' && (
                  <>
                    <div className="space-y-3">
                      <label className="block text-sm font-black text-stone-500 uppercase tracking-widest ml-1">Current Age</label>
                      <input required type="number" className={`w-full border-2 rounded-2xl p-4 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={reportForm.age} onChange={e => setReportForm({...reportForm, age: e.target.value})} />
                    </div>
                    <div className="space-y-3">
                      <label className="block text-sm font-black text-stone-500 uppercase tracking-widest ml-1">Diagnosis / Concern</label>
                      <input required type="text" className={`w-full border-2 rounded-2xl p-4 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={reportForm.disease} onChange={e => setReportForm({...reportForm, disease: e.target.value})} placeholder="e.g. Chronic Fatigue" />
                    </div>
                    <div className="space-y-3">
                      <label className="block text-sm font-black text-stone-500 uppercase tracking-widest ml-1">Treatment Fee ($)</label>
                      <input required type="number" className={`w-full border-2 rounded-2xl p-4 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={reportForm.fee} onChange={e => setReportForm({...reportForm, fee: e.target.value})} placeholder="0.00" />
                    </div>
                  </>
                )}
              </div>
              
              {activeTab === 'medicine' && (
                <>
                  <div className="space-y-3">
                    <label className="block text-sm font-black text-stone-500 uppercase tracking-widest ml-1">Medication Details</label>
                    <textarea 
                      required 
                      rows={6} 
                      className={`w-full border-2 rounded-2xl p-4 font-medium outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} 
                      value={medicineForm.details} 
                      onChange={e => setMedicineForm({...medicineForm, details: e.target.value})} 
                      placeholder="Insert tablet names, dosages, and organic supplements..."
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="block text-sm font-black text-stone-500 uppercase tracking-widest ml-1">Consumption Timing</label>
                    <input required type="text" className={`w-full border-2 rounded-2xl p-4 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={medicineForm.schedule} onChange={e => setMedicineForm({...medicineForm, schedule: e.target.value})} placeholder="e.g. Twice daily, after meals" />
                  </div>
                </>
              )}
              
              <button type="submit" className="bg-red-600 text-white font-black px-12 py-5 rounded-2xl hover:bg-red-700 transition-all shadow-2xl shadow-red-200 dark:shadow-red-950/20 tracking-widest uppercase">
                {activeTab === 'report' ? 'Save Monitoring Data' : 'Securely Commit Prescription'}
              </button>
            </form>
          </div>
        )}
      </main>

       {showAddClient && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xl flex items-center justify-center p-6 z-50">
          <div className={`rounded-[3rem] shadow-2xl w-full max-w-md p-10 border transition-all ${isDarkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-white'}`}>
            <h3 className={`text-3xl font-extrabold mb-8 ${isDarkMode ? 'text-white' : 'text-stone-800'}`}>New Patient Profile</h3>
            <form onSubmit={handleAddClient} className="space-y-5">
              <input required type="text" className={`w-full border-2 p-4 rounded-2xl outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={newClient.fullName} onChange={e => setNewClient({...newClient, fullName: e.target.value})} placeholder="Full Legal Name" />
              <input required type="text" className={`w-full border-2 p-4 rounded-2xl outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={newClient.username} onChange={e => setNewClient({...newClient, username: e.target.value})} placeholder="Login Username" />
              <input required type="password" d-secure="true" className={`w-full border-2 p-4 rounded-2xl outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={newClient.password} onChange={e => setNewClient({...newClient, password: e.target.value})} placeholder="Secure Password" />
              <div className="flex gap-4 pt-6">
                <button type="button" onClick={() => setShowAddClient(false)} className={`flex-1 font-bold py-4 rounded-2xl transition-all ${isDarkMode ? 'text-stone-500 hover:text-stone-300' : 'text-stone-400 hover:text-stone-600'}`}>Discard</button>
                <button type="submit" className="flex-1 bg-red-600 text-white font-bold py-4 rounded-2xl shadow-xl shadow-red-200">Establish Profile</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DoctorDashboard;