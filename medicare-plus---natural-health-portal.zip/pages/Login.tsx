import React, { useState } from 'react';
import { User } from '../types';
import { db } from '../services/database';

interface LoginProps {
  onLogin: (user: User) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, isDarkMode, toggleTheme }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const users = db.getUsers();
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
      sessionStorage.setItem('logged_user', JSON.stringify(user));
      onLogin(user);
    } else {
      setError('Invalid credentials. Please try again.');
    }
  };

  return (
    <div className={`flex min-h-screen items-center justify-center p-6 transition-colors duration-300 ${isDarkMode ? 'bg-stone-950' : 'natural-gradient'}`}>
      {/* Theme Toggle Button */}
      <button 
        onClick={toggleTheme}
        className="fixed top-8 right-8 p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 hover:scale-110 transition-all z-50 text-red-500 shadow-xl"
      >
        {isDarkMode ? (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
        )}
      </button>

      <div className={`w-full max-w-md backdrop-blur-xl rounded-[2.5rem] shadow-2xl overflow-hidden border transition-all duration-300 ${isDarkMode ? 'bg-stone-900/80 border-stone-800 shadow-red-900/10' : 'bg-white/80 border-white shadow-red-900/5'}`}>
        <div className="bg-red-600 p-10 text-center text-white relative">
          <div className="absolute top-0 right-0 opacity-10 transform translate-x-4 -translate-y-4">
             <svg width="120" height="120" viewBox="0 0 24 24" fill="currentColor"><path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,11 17,8 17,8Z"/></svg>
          </div>
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 rounded-3xl mb-6 backdrop-blur-md">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight">Medicare <span className="text-red-200">Plus</span></h1>
          <p className="mt-2 text-red-50 font-medium">Harmonizing Health with Nature</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-10 space-y-6">
          {error && <div className="bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400 p-4 rounded-2xl text-sm text-center font-semibold border border-red-100 dark:border-red-900/50">{error}</div>}
          
          <div className="space-y-2">
            <label className={`block text-sm font-bold ml-1 transition-colors ${isDarkMode ? 'text-stone-400' : 'text-stone-600'}`}>Username</label>
            <input 
              type="text" 
              required
              className={`w-full px-5 py-4 rounded-2xl border-2 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500 focus:ring-red-900/30' : 'bg-stone-50/50 border-stone-100 focus:bg-white focus:border-red-500 focus:ring-red-100'}`}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin / doctor"
            />
          </div>
          
          <div className="space-y-2">
            <label className={`block text-sm font-bold ml-1 transition-colors ${isDarkMode ? 'text-stone-400' : 'text-stone-600'}`}>Password</label>
            <input 
              type="password" 
              required
              className={`w-full px-5 py-4 rounded-2xl border-2 outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500 focus:ring-red-900/30' : 'bg-stone-50/50 border-stone-100 focus:bg-white focus:border-red-500 focus:ring-red-100'}`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          
          <button 
            type="submit" 
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-4 rounded-2xl shadow-xl shadow-red-200 dark:shadow-red-950/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            Enter Portal
          </button>

          <div className="text-center pt-4">
            <p className="text-xs text-stone-400 font-medium tracking-widest uppercase">Safe • Natural • Professional</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;