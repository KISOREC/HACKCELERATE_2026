import React, { useState } from 'react';
import { User, ClientReport } from '../types';
import { db } from '../services/database';

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ user, onLogout, isDarkMode, toggleTheme }) => {
  const [activeTab, setActiveTab] = useState<'doctors' | 'reports'>('doctors');
  const [showAddDoctor, setShowAddDoctor] = useState(false);
  const [newDoc, setNewDoc] = useState({ username: '', password: '', fullName: '' });

  const doctors = db.getUsers().filter(u => u.role === 'DOCTOR');
  const allReports = db.getReports();

  const handleAddDoctor = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      username: newDoc.username,
      password: newDoc.password,
      fullName: newDoc.fullName,
      role: 'DOCTOR'
    };
    db.saveUser(newUser);
    setShowAddDoctor(false);
    setNewDoc({ username: '', password: '', fullName: '' });
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'bg-stone-950' : 'bg-stone-50'}`}>
      <nav className={`border-b px-8 py-5 flex justify-between items-center sticky top-0 z-20 backdrop-blur-md transition-all ${isDarkMode ? 'bg-stone-900/80 border-stone-800' : 'bg-white/80 border-stone-200'}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-red-600 rounded-2xl flex items-center justify-center text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
          </div>
          <div className={`font-black text-2xl tracking-tight transition-colors ${isDarkMode ? 'text-red-400' : 'text-red-800'}`}>MEDICARE<span className={`${isDarkMode ? 'text-stone-500' : 'text-stone-400'} font-medium ml-1`}>ADMIN</span></div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className={`p-2.5 rounded-xl border transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-red-400 hover:bg-stone-700' : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-stone-200'}`}
          >
            {isDarkMode ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg> : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>}
          </button>
          <div className="hidden md:block">
            <p className={`text-[10px] font-bold uppercase tracking-widest ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>Administrator</p>
            <p className={`text-sm font-bold ${isDarkMode ? 'text-stone-200' : 'text-stone-700'}`}>{user.fullName}</p>
          </div>
          <button onClick={onLogout} className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all border ${isDarkMode ? 'bg-stone-800 border-stone-700 text-stone-300 hover:bg-red-900/20 hover:text-red-400' : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-red-50 hover:text-red-600'}`}>Logout</button>
        </div>
      </nav>

      <main className="p-8 max-w-7xl mx-auto">
        <div className={`flex p-1.5 rounded-2xl w-fit mb-10 border transition-all ${isDarkMode ? 'bg-stone-900 border-stone-800' : 'bg-stone-200/50 border-stone-200'}`}>
          <button 
            onClick={() => setActiveTab('doctors')}
            className={`px-8 py-3 rounded-xl font-bold transition-all ${activeTab === 'doctors' ? (isDarkMode ? 'bg-red-600 text-white' : 'bg-white text-red-700 shadow-sm') : (isDarkMode ? 'text-stone-500 hover:text-stone-300' : 'text-stone-500 hover:text-stone-700')}`}
          >
            Practitioners
          </button>
          <button 
            onClick={() => setActiveTab('reports')}
            className={`px-8 py-3 rounded-xl font-bold transition-all ${activeTab === 'reports' ? (isDarkMode ? 'bg-red-600 text-white' : 'bg-white text-red-700 shadow-sm') : (isDarkMode ? 'text-stone-500 hover:text-stone-300' : 'text-stone-500 hover:text-stone-700')}`}
          >
            Health Monitoring
          </button>
        </div>

        {activeTab === 'doctors' ? (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className={`text-3xl font-extrabold ${isDarkMode ? 'text-white' : 'text-stone-800'}`}>Doctor Directory</h2>
                <p className={`${isDarkMode ? 'text-stone-400' : 'text-stone-500'} font-medium`}>Managing clinical staff and professional access.</p>
              </div>
              <button 
                onClick={() => setShowAddDoctor(true)}
                className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-xl shadow-red-200 dark:shadow-red-950/20 transition-all"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                Register Practitioner
              </button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {doctors.map(doc => (
                <div key={doc.id} className={`p-8 rounded-[2rem] border-2 transition-all group ${isDarkMode ? 'bg-stone-900 border-stone-800 hover:border-red-600/50 hover:shadow-2xl hover:shadow-red-900/10' : 'bg-white border-transparent hover:border-red-100 hover:shadow-2xl hover:shadow-red-900/5'}`}>
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-colors ${isDarkMode ? 'bg-stone-800 text-red-400 group-hover:bg-red-600 group-hover:text-white' : 'bg-stone-50 text-red-600 group-hover:bg-red-600 group-hover:text-white'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  </div>
                  <h3 className={`font-bold text-xl mb-1 ${isDarkMode ? 'text-stone-100' : 'text-stone-800'}`}>{doc.fullName}</h3>
                  <p className={`${isDarkMode ? 'text-stone-500' : 'text-stone-400'} text-sm font-semibold mb-6 tracking-wide uppercase`}>ID: {doc.username}</p>
                  <div className={`pt-6 border-t flex justify-between items-center ${isDarkMode ? 'border-stone-800' : 'border-stone-100'}`}>
                    <span className="flex items-center gap-2 text-red-600 font-bold text-xs uppercase tracking-tighter">
                       <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                       Active Practitioner
                    </span>
                    <button className={`${isDarkMode ? 'text-stone-600 hover:text-red-400' : 'text-stone-300 hover:text-red-500'} transition-colors`}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className={`rounded-[2.5rem] border overflow-hidden shadow-2xl transition-all ${isDarkMode ? 'bg-stone-900 border-stone-800 shadow-stone-950/20' : 'bg-white border-stone-200 shadow-stone-900/5'} animate-in fade-in duration-500`}>
            <div className={`p-8 border-b ${isDarkMode ? 'border-stone-800 bg-stone-900/50' : 'border-stone-100 bg-stone-50/50'}`}>
               <h2 className={`text-2xl font-extrabold ${isDarkMode ? 'text-white' : 'text-stone-800'}`}>Master Health Log</h2>
               <p className={`${isDarkMode ? 'text-stone-400' : 'text-stone-500'} font-medium`}>Cross-clinical patient monitoring.</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className={`${isDarkMode ? 'bg-stone-950/50' : 'bg-stone-50/50'}`}>
                  <tr>
                    <th className="px-8 py-5 text-xs font-black text-stone-400 uppercase tracking-widest">Client</th>
                    <th className="px-8 py-5 text-xs font-black text-stone-400 uppercase tracking-widest">Condition</th>
                    <th className="px-8 py-5 text-xs font-black text-stone-400 uppercase tracking-widest">Fee</th>
                    <th className="px-8 py-5 text-xs font-black text-stone-400 uppercase tracking-widest">Attending Dr</th>
                    <th className="px-8 py-5 text-xs font-black text-stone-400 uppercase tracking-widest">Date</th>
                  </tr>
                </thead>
                <tbody className={`divide-y ${isDarkMode ? 'divide-stone-800' : 'divide-stone-100'}`}>
                  {allReports.map(report => (
                    <tr key={report.id} className={`${isDarkMode ? 'hover:bg-red-900/10' : 'hover:bg-red-50/30'} transition-colors`}>
                      <td className="px-8 py-6">
                        <p className={`font-bold ${isDarkMode ? 'text-stone-200' : 'text-stone-800'}`}>{report.clientName}</p>
                        <p className={`text-xs ${isDarkMode ? 'text-stone-500' : 'text-stone-400'} font-medium`}>Age: {report.age}</p>
                      </td>
                      <td className="px-8 py-6">
                        <span className={`px-4 py-1.5 rounded-full text-xs font-bold border uppercase tracking-wide ${isDarkMode ? 'bg-stone-800 border-stone-700 text-stone-300' : 'bg-stone-100 border-stone-200 text-stone-600'}`}>{report.disease}</span>
                      </td>
                      <td className="px-8 py-6 text-red-600 font-black">${report.fee}</td>
                      <td className={`px-8 py-6 font-medium italic ${isDarkMode ? 'text-stone-400' : 'text-stone-600'}`}>{report.doctorName}</td>
                      <td className={`px-8 py-6 text-sm font-bold ${isDarkMode ? 'text-stone-500' : 'text-stone-400'}`}>{report.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {showAddDoctor && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xl flex items-center justify-center p-6 z-50">
          <div className={`rounded-[2.5rem] shadow-2xl w-full max-w-md animate-in zoom-in-95 duration-300 border transition-all ${isDarkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-white'}`}>
            <div className={`p-8 border-b flex justify-between items-center ${isDarkMode ? 'border-stone-800' : 'border-stone-100'}`}>
              <h3 className={`text-2xl font-extrabold ${isDarkMode ? 'text-white' : 'text-stone-800'}`}>Register Practitioner</h3>
              <button onClick={() => setShowAddDoctor(false)} className={`${isDarkMode ? 'text-stone-500 hover:text-white' : 'text-stone-300 hover:text-stone-600'} p-2 transition-colors`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
              </button>
            </div>
            <form onSubmit={handleAddDoctor} className="p-8 space-y-5">
              <div className="space-y-2">
                <label className={`block text-sm font-bold ml-1 ${isDarkMode ? 'text-stone-400' : 'text-stone-600'}`}>Full Name</label>
                <input required type="text" className={`w-full border-2 p-4 rounded-2xl outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={newDoc.fullName} onChange={e => setNewDoc({...newDoc, fullName: e.target.value})} placeholder="Dr. John Nature" />
              </div>
              <div className="space-y-2">
                <label className={`block text-sm font-bold ml-1 ${isDarkMode ? 'text-stone-400' : 'text-stone-600'}`}>Username</label>
                <input required type="text" className={`w-full border-2 p-4 rounded-2xl outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={newDoc.username} onChange={e => setNewDoc({...newDoc, username: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className={`block text-sm font-bold ml-1 ${isDarkMode ? 'text-stone-400' : 'text-stone-600'}`}>Secure Password</label>
                <input required type="password" d-secure="true" className={`w-full border-2 p-4 rounded-2xl outline-none transition-all ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500' : 'bg-stone-50/50 border-stone-100 focus:border-red-500'}`} value={newDoc.password} onChange={e => setNewDoc({...newDoc, password: e.target.value})} />
              </div>
              <button type="submit" className="w-full bg-red-600 text-white font-bold py-4 rounded-2xl mt-4 hover:bg-red-700 transition-all shadow-xl shadow-red-200">Establish Account</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;