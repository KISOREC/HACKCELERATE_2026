
interface OfflineMedicalData {
  [key: string]: {
    explanation: string;
    firstAid: string;
    medicine: string;
  };
}

const LOCAL_KNOWLEDGE: OfflineMedicalData = {
  "fever": {
    explanation: "Fever is your body's way of fighting infection. காய்ச்சல் என்பது தொற்றுநோயை எதிர்க்கும் உடல் முறை.",
    firstAid: "Rest, drink plenty of fluids, and use a cool sponge bath. ஓய்வு, அதிக நீர் குடிக்கவும், உடல் வெப்பத்தை குறைக்க ஈரத் துணியால் துடைக்கவும்.",
    medicine: "Paracetamol (Standard dosage based on age)."
  },
  "cough": {
    explanation: "Irritation in the throat or lungs usually caused by viruses. தொண்டை அல்லது நுரையீரல் எரிச்சல், பொதுவாக வைரஸால் ஏற்படுகிறது.",
    firstAid: "Drink warm water with honey, perform steam inhalation. வெதுவெதுப்பான நீர், தேன் சேர்த்து குடிக்கவும் மற்றும் ஆவி பிடிக்கவும்.",
    medicine: "Expectorant syrup or herbal ginger tea."
  },
  "headache": {
    explanation: "Usually caused by stress, dehydration, or eye strain. தலைவலி பொதுவாக மன அழுத்தம் அல்லது நீர்ச்சத்து குறைவினால் ஏற்படுகிறது.",
    firstAid: "Rest in a dark, quiet room and stay hydrated. இருண்ட, அமைதியான அறையில் ஓய்வெடுக்கவும் மற்றும் நீர் குடிக்கவும்.",
    medicine: "Aspirin, Ibuprofen, or Balm application."
  },
  "stomach": {
    explanation: "Pain in the abdomen often due to indigestion or gas. அஜீரணம் அல்லது வாயுவினால் ஏற்படும் வயிற்று வலி.",
    firstAid: "Drink ginger water or buttermilk. Avoid solid food for a few hours. இஞ்சி நீர் அல்லது மோர் குடிக்கவும். சில மணிநேரம் திட உணவை தவிர்க்கவும்.",
    medicine: "Antacids or Pepto-Bismol."
  },
  "rash": {
    explanation: "Skin irritation caused by allergies, heat, or chemicals. ஒவ்வாமை அல்லது வெப்பத்தினால் ஏற்படும் தோல் எரிச்சல்.",
    firstAid: "Wash with cool water, apply aloe vera or calamine lotion. குளிர்ந்த நீரால் கழுவவும், கற்றாழை அல்லது கலாமைன் லோஷன் தடவவும்.",
    medicine: "Antihistamines (Cetirizine) if due to allergy."
  },
  "diarrhea": {
    explanation: "Loose stools leading to rapid fluid loss. வயிற்றுப்போக்கு, உடலில் நீர்ச்சத்து குறைய வழிவகுக்கும்.",
    firstAid: "Drink ORS (Oral Rehydration Solution) or salt-sugar water. ORS அல்லது உப்பு-சர்க்கரை கரைசல் குடிக்கவும்.",
    medicine: "Loperamide (for adults) and Probiotics."
  },
  "burn": {
    explanation: "Damage to the skin caused by heat or fire. வெப்பம் அல்லது நெருப்பினால் தோலில் ஏற்படும் காயம்.",
    firstAid: "Run cool (not cold) water over the area for 10-15 mins. 10-15 நிமிடங்கள் காயத்தின் மேல் குளிர்ந்த நீரை ஊற்றவும்.",
    medicine: "Silver sulfadiazine cream or antibiotic ointment."
  },
  "sprain": {
    explanation: "Injury to a ligament caused by sudden stretching. திடீர் இழுப்பினால் ஏற்படும் தசைநாண் காயம்.",
    firstAid: "R.I.C.E: Rest, Ice, Compression, Elevation. ஓய்வு, ஐஸ் கட்டி, அழுத்தம், மற்றும் காயப்பட்ட பகுதியை உயர்த்தி வைக்கவும்.",
    medicine: "Pain relievers like Ibuprofen."
  },
  "cold": {
    explanation: "Viral infection of the nose and throat. மூக்கு மற்றும் தொண்டையில் ஏற்படும் வைரஸ் தொற்று.",
    firstAid: "Keep warm, gargle with salt water, and stay hydrated. உடலை கதகதப்பாக வைக்கவும், உப்பு நீரால் தொண்டையை கொப்பளிக்கவும்.",
    medicine: "Vitamin C, Zinc lozenges, or Decongestants."
  },
  "sore throat": {
    explanation: "Pain or scratchiness in the throat, often worse when swallowing. தொண்டை வலி, விழுங்கும்போது எரிச்சல் ஏற்படும்.",
    firstAid: "Gargle with warm salt water and drink warm herbal tea. வெதுவெதுப்பான உப்பு நீரால் கொப்பளிக்கவும் மற்றும் மூலிகை டீ குடிக்கவும்.",
    medicine: "Throat lozenges or salt-water gargle."
  },
  "conjunctivitis": {
    explanation: "Inflammation or infection of the outer membrane of the eyeball (Pink eye). கண் விழித்திரையில் ஏற்படும் தொற்று (மெட்ராஸ் ஐ).",
    firstAid: "Avoid touching eyes, use a clean damp cloth to wipe. கண்களைத் தொடுவதைத் தவிர்க்கவும், சுத்தமான துணியால் துடைக்கவும்.",
    medicine: "Antibiotic eye drops (consult via video soon)."
  },
  "cut": {
    explanation: "A break or opening in the skin from an injury. காயம் அல்லது வெட்டு காயம்.",
    firstAid: "Clean with soap and water, apply pressure to stop bleeding. சோப்பு மற்றும் நீரால் சுத்தப்படுத்தவும், ரத்தத்தை நிறுத்த அழுத்தம் கொடுக்கவும்.",
    medicine: "Antiseptic cream (Betadine) and a clean bandage."
  },
  "insect bite": {
    explanation: "Reaction to a sting or bite from an insect. பூச்சி கடி அல்லது கொட்டுதலால் ஏற்படும் எதிர்வினை.",
    firstAid: "Remove the stinger if present, apply ice, and keep clean. கொடுக்கை நீக்கவும், ஐஸ் வைக்கவும் மற்றும் சுத்தமாக வைக்கவும்.",
    medicine: "Hydrocortisone cream or Antihistamines."
  }
};

export const getOfflineAdvice = (input: string) => {
  const lowInput = input.toLowerCase();
  for (const key in LOCAL_KNOWLEDGE) {
    if (lowInput.includes(key)) {
      return LOCAL_KNOWLEDGE[key];
    }
  }
  return null;
};
