
import { User, ClientReport, ClientMedicine } from '../types';

const USERS_KEY = 'hms_users';
const REPORTS_KEY = 'hms_reports';
const MEDICINES_KEY = 'hms_medicines';

const defaultUsers: User[] = [
  { id: '1', username: 'admin', password: 'admin123', role: 'ADMIN', fullName: 'System Administrator' },
  { id: '2', username: 'doctor', password: 'doctor123', role: 'DOCTOR', fullName: 'Dr. John Doe' }
];

export const db = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : defaultUsers;
  },
  saveUser: (user: User) => {
    const users = db.getUsers();
    users.push(user);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },
  getReports: (): ClientReport[] => {
    const data = localStorage.getItem(REPORTS_KEY);
    return data ? JSON.parse(data) : [];
  },
  saveReport: (report: ClientReport) => {
    const reports = db.getReports();
    reports.push(report);
    localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
  },
  getMedicines: (): ClientMedicine[] => {
    const data = localStorage.getItem(MEDICINES_KEY);
    return data ? JSON.parse(data) : [];
  },
  saveMedicine: (medicine: ClientMedicine) => {
    const medicines = db.getMedicines();
    medicines.push(medicine);
    localStorage.setItem(MEDICINES_KEY, JSON.stringify(medicines));
  }
};
