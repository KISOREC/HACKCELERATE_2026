
import React, { useState, useEffect } from 'react';
import { User, UserRole } from './types';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import DoctorDashboard from './pages/DoctorDashboard';
import ClientDashboard from './pages/ClientDashboard';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme_mode');
    return saved === 'dark';
  });

  useEffect(() => {
    const savedUser = sessionStorage.getItem('logged_user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }

    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch(err => console.log('SW registration failed:', err));
      });
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('theme_mode', isDarkMode ? 'dark' : 'light');
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleLogout = () => {
    sessionStorage.removeItem('logged_user');
    setCurrentUser(null);
  };

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  const renderDashboard = () => {
    if (!currentUser) return <Login onLogin={setCurrentUser} isDarkMode={isDarkMode} toggleTheme={toggleTheme} />;

    switch (currentUser.role) {
      case 'ADMIN':
        return <AdminDashboard user={currentUser} onLogout={handleLogout} isDarkMode={isDarkMode} toggleTheme={toggleTheme} />;
      case 'DOCTOR':
        return <DoctorDashboard user={currentUser} onLogout={handleLogout} isDarkMode={isDarkMode} toggleTheme={toggleTheme} />;
      case 'CLIENT':
        return <ClientDashboard user={currentUser} onLogout={handleLogout} isDarkMode={isDarkMode} toggleTheme={toggleTheme} />;
      default:
        return <Login onLogin={setCurrentUser} isDarkMode={isDarkMode} toggleTheme={toggleTheme} />;
    }
  };

  return (
    <div className={`min-h-screen relative overflow-x-hidden transition-colors duration-300 ${isDarkMode ? 'bg-stone-950 text-stone-100' : 'bg-stone-50 text-stone-900'}`}>
      {renderDashboard()}
      <Chatbot isDarkMode={isDarkMode} />
    </div>
  );
};

export default App;
