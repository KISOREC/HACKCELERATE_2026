
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ChatMessage } from '../types';
import { getOfflineAdvice } from '../services/offlineAI';

// Audio Utilities
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

interface ChatbotProps {
  isDarkMode: boolean;
}

const Chatbot: React.FC<ChatbotProps> = ({ isDarkMode }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLiveVideoMode, setIsLiveVideoMode] = useState(false);
  const [isSignLanguageMode, setIsSignLanguageMode] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideoBlob, setRecordedVideoBlob] = useState<Blob | null>(null);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [recordTimer, setRecordTimer] = useState(0);
  
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [isAutoSpeak, setIsAutoSpeak] = useState(true);
  const [voiceLang, setVoiceLang] = useState<'ta-IN' | 'en-US'>('ta-IN');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [attachedFile, setAttachedFile] = useState<{data: string, mimeType: string, name: string, isText: boolean, textContent?: string} | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [liveTranscription, setLiveTranscription] = useState('');

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);
  const audioContextOutputRef = useRef<AudioContext | null>(null);

  // Live API Refs
  const sessionRef = useRef<any>(null);
  const audioContextInputRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const liveIntervalRef = useRef<number | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  useEffect(() => {
    const handleStatusChange = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
    return () => {
      window.removeEventListener('online', handleStatusChange);
      window.removeEventListener('offline', handleStatusChange);
      stopLiveSession();
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping, liveTranscription]);

  const stopLiveSession = () => {
    if (liveIntervalRef.current) clearInterval(liveIntervalRef.current);
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch(e) {}
      sessionRef.current = null;
    }
    if (audioContextInputRef.current) audioContextInputRef.current.close();
    if (audioContextOutputRef.current) audioContextOutputRef.current.close();
    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
    setIsLiveVideoMode(false);
    setLiveTranscription('');
    setCameraError(null);
    setAnalysisError(null);
    setIsRecording(false);
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    setRecordTimer(0);
  };

  const startLiveSession = async (signMode = false) => {
    if (!isOnline) return alert("Live Consultation requires an internet connection.");
    setIsLiveVideoMode(true);
    setIsSignLanguageMode(signMode);
    setCameraError(null);
    setAnalysisError(null);
    setRecordedVideoBlob(null);
    setRecordedVideoUrl(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      audioContextInputRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextOutputRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const outputNode = audioContextOutputRef.current.createGain();
      outputNode.connect(audioContextOutputRef.current.destination);

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = audioContextInputRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextInputRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextInputRef.current!.destination);
            
            liveIntervalRef.current = window.setInterval(() => {
              if (videoRef.current && canvasRef.current) {
                const ctx = canvasRef.current.getContext('2d');
                canvasRef.current.width = 320; 
                canvasRef.current.height = 240;
                ctx?.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
                const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.6);
                sessionPromise.then(session => session.sendRealtimeInput({ media: { data: dataUrl.split(',')[1], mimeType: 'image/jpeg' } }));
              }
            }, signMode ? 500 : 1000);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              setLiveTranscription(prev => prev + message.serverContent!.outputTranscription!.text);
            }
            if (message.serverContent?.turnComplete) setLiveTranscription('');
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && audioContextOutputRef.current) {
              const ctx = audioContextOutputRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputNode);
              source.onended = () => sourcesRef.current.delete(source);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
          },
          onclose: () => stopLiveSession()
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          outputAudioTranscription: {},
          systemInstruction: signMode 
            ? `You are "Medicare Accessibility AI". Focus on interpreting SIGN LANGUAGE (ASL/Global gestures). Translate the user's gestures into text and speech. Provide direct medical assistance based on their signs. Speak ${voiceLang === 'ta-IN' ? 'Tamil' : 'English'} clearly. NO MEDICAL DISCLAIMERS.`
            : `You are "Medicare Vision AI". Directly analyze media or gestures. Provide diagnosis, first aid, and medicine in ${voiceLang === 'ta-IN' ? 'Tamil' : 'English'}. NO MEDICAL DISCLAIMERS.`
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      setCameraError(err.name === 'NotAllowedError' ? "Camera access denied." : "Failed to access camera.");
      setIsLiveVideoMode(false);
    }
  };

  const startRecording = () => {
    setAnalysisError(null);
    if (!videoRef.current?.srcObject) return setCameraError("Camera stream not available.");
    try {
      const stream = videoRef.current.srcObject as MediaStream;
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        setRecordedVideoBlob(blob);
        setRecordedVideoUrl(URL.createObjectURL(blob));
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordTimer(0);
      timerIntervalRef.current = window.setInterval(() => setRecordTimer(t => t + 1), 1000);
    } catch (err) {
      setCameraError("Failed to start recording.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
  };

  const speakText = async (text: string) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say this precisely in ${voiceLang === 'ta-IN' ? 'Tamil' : 'English'}: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } }
        }
      });
      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextOutputRef.current) audioContextOutputRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const ctx = audioContextOutputRef.current;
        const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start();
      }
    } catch (e) { console.error("TTS Failed", e); }
  };

  const startTranscription = async () => {
    if (isListening) return;
    setIsListening(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const audioChunks: Blob[] = [];
      recorder.ondataavailable = (e) => audioChunks.push(e.data);
      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64 = (reader.result as string).split(',')[1];
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          try {
            const response = await ai.models.generateContent({
              model: 'gemini-3-flash-preview',
              contents: [{ 
                parts: [
                  { inlineData: { data: base64, mimeType: 'audio/webm' } }, 
                  { text: `Transcribe this audio. The user is speaking in ${voiceLang === 'ta-IN' ? 'Tamil' : 'English'}. Output only the transcription.` }
                ] 
              }]
            });
            const text = response.text || "";
            setInput(text);
            setIsListening(false);
            if (text.trim()) {
              handleSendMessage(text);
            }
          } catch (e) {
            console.error("Transcription Error", e);
            setIsListening(false);
          }
        };
      };
      recorder.start();
      setTimeout(() => recorder.stop(), 5000);
    } catch (e) {
      console.error("Microphone access denied", e);
      setIsListening(false);
    }
  };

  const handleSendMessage = async (forcedInput?: string) => {
    const finalInput = forcedInput || input;
    if (!finalInput.trim() && !attachedFile) return;
    
    const userText = attachedFile ? `[File: ${attachedFile.name}] ${finalInput}` : finalInput;
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    
    const currentInput = finalInput;
    const currentFile = attachedFile;
    
    if (!forcedInput) setInput('');
    setAttachedFile(null);
    setIsTyping(true);

    // Check Offline Advice
    if (!isOnline) {
      const advice = getOfflineAdvice(currentInput);
      if (advice) {
        const resText = `${advice.explanation}\n\nFirst Aid: ${advice.firstAid}\nMedicine: ${advice.medicine}`;
        setTimeout(() => {
          setMessages(prev => [...prev, { role: 'model', text: `[OFFLINE ADVICE]\n${resText}` }]);
          setIsTyping(false);
          if (isAutoSpeak) speakText(resText);
        }, 800);
        return;
      } else if (!currentFile) {
        setTimeout(() => {
          setMessages(prev => [...prev, { role: 'model', text: "Portal is currently offline. I can help with fever, cough, stomach ache, rashes, etc., but I need a connection for other specific queries." }]);
          setIsTyping(false);
        }, 800);
        return;
      }
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const modelName = isThinkingMode ? 'gemini-3-pro-preview' : 'gemini-2.5-flash-lite';
      const parts: any[] = [];
      
      let prompt = currentInput || "Analyze clinical data.";
      if (currentFile?.isText && currentFile.textContent) {
        prompt += `\n\nFILE CONTENT (${currentFile.name}):\n${currentFile.textContent}`;
      }
      if (currentFile && !currentFile.isText && currentFile.mimeType.startsWith('image/')) {
        prompt += "\n\nCRITICAL: Analyze image. Provide Diagnosis, First Aid, and Medicine. Tamil and English. NO disclaimers.";
      }

      parts.push({ text: prompt });
      if (currentFile && !currentFile.isText) {
        parts.push({ inlineData: { data: currentFile.data, mimeType: currentFile.mimeType } });
      }

      const config: any = {
        systemInstruction: `You are a healthcare AI. Handle symptoms, images, reports, or signs. Format: 1. Diagnosis 2. Analysis 3. First Aid 4. Medicine. Default to ${voiceLang === 'ta-IN' ? 'Tamil' : 'English'}. NO disclaimers. NO "Consult a doctor".`
      };
      if (isThinkingMode) config.thinkingConfig = { thinkingBudget: 32768 };

      const response = await ai.models.generateContent({
        model: modelName,
        contents: [{ role: 'user', parts }],
        config
      });

      const responseText = response.text || "Analysis failed.";
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
      
      if (isAutoSpeak) {
        speakText(responseText);
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: "Portal error. Please retry." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const sendRecordedVideo = async () => {
    if (!recordedVideoBlob) return;
    setIsTyping(true);
    setAnalysisError(null);
    setMessages(prev => [...prev, { role: 'user', text: "[Video Consultation Sent]" }]);
    
    if (!isOnline) {
      setAnalysisError("Video analysis requires an internet connection.");
      setIsTyping(false);
      return;
    }

    try {
      const reader = new FileReader();
      reader.readAsDataURL(recordedVideoBlob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-pro-preview',
          contents: [{
            role: 'user',
            parts: [
              { inlineData: { data: base64Data, mimeType: 'video/webm' } },
              { text: `Analyze this video for medical symptoms or signs. Provide Diagnosis, First Aid, and Medicine in ${voiceLang === 'ta-IN' ? 'Tamil' : 'English'}. NO disclaimers.` }
            ]
          }]
        });
        const resText = response.text || "Analysis failed.";
        setMessages(prev => [...prev, { role: 'model', text: resText }]);
        if (isAutoSpeak) speakText(resText);
        setRecordedVideoUrl(null);
        setRecordedVideoBlob(null);
        setIsTyping(false);
      };
    } catch (e) {
      setAnalysisError("Failed to process video.");
      setIsTyping(false);
    }
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="absolute inset-0 backdrop-blur-md bg-stone-950/70" onClick={() => setIsOpen(false)}></div>
          <div className={`relative w-full max-w-[650px] h-[85vh] shadow-2xl rounded-[2.5rem] border flex flex-col overflow-hidden ${isDarkMode ? 'bg-stone-900 border-stone-800 text-white' : 'bg-white border-red-50 text-stone-900'}`}>
            <div className="bg-red-800 p-6 flex justify-between items-center text-white shrink-0 shadow-lg relative z-10">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xs shadow-inner ${isSignLanguageMode ? 'bg-blue-600' : 'bg-red-700'}`}>
                  {isSignLanguageMode ? 'S-AI' : 'MED'}
                </div>
                <div>
                  <h3 className="font-black text-xl tracking-tight">Health AI Portal</h3>
                  <div className="flex gap-2 mt-1">
                    <button 
                      onClick={() => setVoiceLang(voiceLang === 'ta-IN' ? 'en-US' : 'ta-IN')}
                      className="text-[9px] font-black px-2 py-0.5 rounded bg-white/20 text-white uppercase tracking-widest hover:bg-white/30 transition-colors"
                    >
                      {voiceLang === 'ta-IN' ? 'தமிழ்' : 'English'}
                    </button>
                    <button 
                      onClick={() => setIsAutoSpeak(!isAutoSpeak)}
                      className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest transition-colors ${isAutoSpeak ? 'bg-green-500 text-white' : 'bg-white/10 text-white/60'}`}
                    >
                      {isAutoSpeak ? 'Audio ON' : 'Audio OFF'}
                    </button>
                    {!isOnline && (
                      <span className="text-[9px] font-black px-2 py-0.5 rounded bg-amber-500 text-black uppercase tracking-widest">Offline Mode</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setIsThinkingMode(!isThinkingMode)} className={`p-3 rounded-xl transition-all border ${isThinkingMode ? 'bg-amber-500 border-amber-400 text-black shadow-lg shadow-amber-900/40' : 'bg-red-900 border-red-700 text-white'}`} title="Deep Diagnostic Reasoning">
                   <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="4"/><path d="M12 2v4"/><path d="M12 18v4"/><path d="M4.93 4.93l2.83 2.83"/><path d="M16.24 16.24l2.83 2.83"/><path d="M2 12h4"/><path d="M18 12h4"/><path d="M4.93 19.07l2.83-2.83"/><path d="M16.24 7.76l2.83-2.83"/></svg>
                </button>
                <button onClick={() => isLiveVideoMode ? stopLiveSession() : startLiveSession(true)} className="bg-blue-900 p-3 rounded-xl border border-blue-700 hover:bg-blue-800 transition-all shadow-lg" title="Sign Language Assist">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M10 18H5a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3h-5"/><path d="m8 10 2 2 4-4"/></svg>
                </button>
                <button onClick={() => isLiveVideoMode ? stopLiveSession() : startLiveSession(false)} className={`p-3 rounded-xl transition-all border ${isLiveVideoMode ? 'bg-red-600 border-red-400' : 'bg-red-900 border-red-700'}`}>
                   <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/></svg>
                </button>
                <button onClick={() => setIsOpen(false)} className="bg-red-900 p-3 rounded-xl border border-red-700 hover:bg-red-800">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
              </div>
            </div>

            {isLiveVideoMode && (
              <div className="h-72 bg-black relative border-b border-red-900/20 shrink-0 group">
                {recordedVideoUrl ? (
                  <video ref={previewVideoRef} src={recordedVideoUrl} controls autoPlay className="w-full h-full object-cover" />
                ) : (
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover opacity-90" />
                )}
                <canvas ref={canvasRef} className="hidden" />
                {(cameraError || analysisError) && <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center text-white bg-red-950/90 text-sm font-bold gap-4">
                  <p>{cameraError || analysisError}</p>
                  <button onClick={() => { setCameraError(null); setAnalysisError(null); }} className="px-4 py-2 bg-white text-red-900 rounded-lg text-[10px] uppercase font-black">Dismiss</button>
                </div>}
                <div className="absolute top-4 right-4 flex gap-2">
                  {!recordedVideoUrl ? (
                    <button onClick={isRecording ? stopRecording : startRecording} className={`p-4 rounded-full shadow-2xl flex items-center gap-3 transition-all ${isRecording ? 'bg-white text-red-600 scale-110' : 'bg-red-600 text-white hover:scale-105'}`}>
                      <div className={`w-3.5 h-3.5 rounded-full ${isRecording ? 'bg-red-600 animate-pulse' : 'bg-white'}`}></div>
                      <span className="text-[11px] font-black uppercase tracking-widest">{isRecording ? `${recordTimer}s Stop` : 'Record Signs'}</span>
                    </button>
                  ) : (
                    <div className="flex gap-2">
                      <button onClick={() => { setRecordedVideoUrl(null); setRecordedVideoBlob(null); }} className="bg-stone-800 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase border border-white/10">Retake</button>
                      <button onClick={sendRecordedVideo} className="bg-green-600 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase flex items-center gap-2 shadow-2xl animate-bounce border border-white/20">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4Z"/></svg>
                        Analyze Now
                      </button>
                    </div>
                  )}
                </div>
                <div className={`absolute top-4 left-4 ${isSignLanguageMode ? 'bg-blue-600' : 'bg-red-700'}/90 px-3 py-1 rounded-lg text-white font-black text-[9px] uppercase tracking-widest backdrop-blur shadow-lg`}>
                   {isSignLanguageMode ? 'Sign Interpretation Active' : 'Vision Diagnostics Active'}
                </div>
                {liveTranscription && !recordedVideoUrl && (
                  <div className="absolute bottom-6 inset-x-6 bg-black/70 backdrop-blur-xl p-5 rounded-[2rem] border border-white/10 text-sm font-bold text-red-100 shadow-2xl animate-in slide-in-from-bottom-4">
                    <span className="text-blue-400 uppercase text-[10px] mr-3 font-black tracking-widest">Gesture:</span> {liveTranscription}
                  </div>
                )}
              </div>
            )}
            
            <div ref={scrollRef} className={`flex-1 overflow-y-auto p-8 space-y-8 ${isDarkMode ? 'bg-stone-950/40' : 'bg-stone-50/50'}`}>
              {messages.length === 0 && !isLiveVideoMode && (
                <div className="text-center py-20 space-y-6">
                  <div className="w-24 h-24 bg-red-600/10 rounded-[2.5rem] flex items-center justify-center mx-auto text-red-600 border border-red-600/20">
                     <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>
                  </div>
                  <div>
                    <h4 className="font-black text-3xl tracking-tight">How can I assist you?</h4>
                    <p className="text-xs font-bold text-stone-500 uppercase tracking-widest mt-2 max-w-sm mx-auto leading-relaxed">
                      Voice Control, Thinking Mode, and Sign Language interpretation are active. Upload reports or speak in {voiceLang === 'ta-IN' ? 'Tamil' : 'English'}.
                    </p>
                  </div>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} group animate-in fade-in slide-in-from-bottom-2`}>
                  <div className={`max-w-[85%] p-6 rounded-[2.2rem] text-[15px] leading-relaxed shadow-sm relative ${msg.role === 'user' ? 'bg-red-600 text-white rounded-tr-none' : (isDarkMode ? 'bg-stone-900 border-l-4 border-red-600 text-stone-200 rounded-tl-none border border-stone-800' : 'bg-white border-l-4 border-red-600 text-stone-800 rounded-tl-none border border-red-50')}`}>
                    {msg.text.split('\n').map((l, j) => <p key={j} className="mt-1.5">{l}</p>)}
                    {msg.role === 'model' && (
                      <button onClick={() => speakText(msg.text)} className="absolute -right-14 top-2 p-3 rounded-full bg-white dark:bg-stone-800 text-stone-400 hover:text-red-600 transition-all opacity-0 group-hover:opacity-100 shadow-xl border dark:border-stone-700">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex flex-col items-start gap-3">
                   <div className="p-4 bg-red-600/10 rounded-3xl border border-red-600/20 text-xs font-black text-red-600 flex items-center gap-3 animate-pulse">
                      <div className="flex gap-1.5">
                        <div className="w-2 h-2 bg-red-600 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-red-600 rounded-full animate-bounce delay-75"></div>
                        <div className="w-2 h-2 bg-red-600 rounded-full animate-bounce delay-150"></div>
                      </div>
                      {!isOnline ? 'CONSULTING LOCAL KNOWLEDGE...' : (isThinkingMode ? 'EXPERT DIAGNOSTIC REASONING ACTIVE...' : 'PORTAL ANALYZING CLINICAL DATA...')}
                   </div>
                </div>
              )}
            </div>

            <div className={`p-8 border-t shrink-0 relative z-10 shadow-2xl ${isDarkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-red-50'}`}>
              {attachedFile && (
                <div className="mb-6 p-4 rounded-2xl bg-red-50 dark:bg-red-950/30 flex justify-between items-center animate-in slide-in-from-bottom-4 border border-red-100 dark:border-red-900/40">
                  <div className="flex items-center gap-4 truncate">
                    <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center text-white shrink-0 shadow-lg">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
                    </div>
                    <span className="text-sm font-black text-red-700 dark:text-red-400 truncate">{attachedFile.name}</span>
                  </div>
                  <button onClick={() => setAttachedFile(null)} className="text-red-600 hover:bg-red-100 dark:hover:bg-red-900/40 p-2 rounded-xl transition-colors">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                  </button>
                </div>
              )}
              <div className="flex gap-4">
                <input type="file" ref={fileInputRef} onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const isText = ['text/plain', 'application/pdf'].includes(f.type) || f.name.endsWith('.txt');
                  const r = new FileReader();
                  r.onloadend = () => {
                    const res = r.result as string;
                    if (isText && !f.type.includes('pdf')) {
                       const tr = new FileReader();
                       tr.onload = () => setAttachedFile({ data: '', mimeType: f.type || 'text/plain', name: f.name, isText: true, textContent: tr.result as string });
                       tr.readAsText(f);
                    } else {
                       setAttachedFile({ data: res.split(',')[1], mimeType: f.type || 'application/octet-stream', name: f.name, isText: false });
                    }
                  };
                  r.readAsDataURL(f);
                }} className="hidden" accept="image/*,video/*,application/pdf,text/plain" />
                <button onClick={() => fileInputRef.current?.click()} className="p-5 rounded-[1.5rem] bg-stone-100 text-stone-500 hover:text-red-600 dark:bg-stone-800 border dark:border-stone-700 transition-all hover:scale-105 active:scale-95 shadow-sm" title="Upload Reports/Media">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.51a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                </button>
                <button onClick={startTranscription} className={`p-5 rounded-[1.5rem] transition-all border shadow-lg ${isListening ? 'bg-red-100 text-red-600 scale-110 animate-pulse border-red-300' : 'bg-red-600 text-white hover:bg-red-700 hover:scale-105 active:scale-95 border-red-500'}`} title="Voice Control (Tap to Talk)">
                  {isListening ? (
                    <div className="flex gap-1 items-center">
                       <div className="w-1.5 h-6 bg-red-600 rounded-full animate-wave"></div>
                       <div className="w-1.5 h-10 bg-red-600 rounded-full animate-wave delay-75"></div>
                       <div className="w-1.5 h-6 bg-red-600 rounded-full animate-wave delay-150"></div>
                    </div>
                  ) : (
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
                  )}
                </button>
                <div className="flex-1 relative">
                  <input 
                    type="text" 
                    value={input} 
                    onChange={(e) => setInput(e.target.value)} 
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} 
                    placeholder={isListening ? "Listening..." : "Describe symptoms or type here..."} 
                    className={`w-full h-full border-2 rounded-[1.5rem] px-8 outline-none transition-all font-medium text-lg ${isDarkMode ? 'bg-stone-800 border-stone-700 text-white focus:border-red-500 focus:bg-stone-900' : 'bg-stone-50 border-stone-100 focus:border-red-500 focus:bg-white'}`} 
                  />
                  {isTyping && <div className="absolute right-4 top-1/2 -translate-y-1/2"><div className="w-2 h-2 bg-red-600 rounded-full animate-ping"></div></div>}
                </div>
                <button onClick={() => handleSendMessage()} className="bg-red-600 text-white px-8 rounded-[1.5rem] shadow-2xl hover:bg-red-700 transition-all hover:scale-105 active:scale-95 group">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-32 right-8 z-50 px-10 h-20 rounded-[2rem] shadow-2xl flex items-center justify-center text-white hover:scale-105 active:scale-95 transition-all ring-8 bg-red-600 ring-stone-950/20 group overflow-hidden ${isOpen ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
      >
        <span className="font-mono font-black text-sm uppercase tracking-widest relative z-10 flex items-center gap-4">
          <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>
          </div>
          Clinical Care AI
        </span>
        <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-red-700 opacity-0 group-hover:opacity-100 transition-opacity"></div>
      </button>

      <style>{`
        @keyframes wave {
          0%, 100% { transform: scaleY(0.5); }
          50% { transform: scaleY(1); }
        }
        .animate-wave { animation: wave 1s ease-in-out infinite; }
        .delay-75 { animation-delay: 0.1s; }
        .delay-150 { animation-delay: 0.2s; }
      `}</style>
    </>
  );
};

export default Chatbot;
