export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

export const playAudioContent = async (base64Audio: string, mimeType: string = 'audio/mp3'): Promise<HTMLAudioElement> => {
  const audio = new Audio(`data:${mimeType};base64,${base64Audio}`);
  await audio.play();
  return audio;
};
