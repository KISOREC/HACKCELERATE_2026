import { GoogleGenAI, Modality, Part } from "@google/genai";
import { LocationData, GroundingLink } from "../types";

// Ensure API Key is available
const apiKey = process.env.API_KEY;
if (!apiKey) {
  console.error("API_KEY is missing via process.env.API_KEY");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "" });

const SYSTEM_INSTRUCTION = `
You are "Gramathu Maruthuvar" (Village Doctor), a warm, compassionate, and highly intelligent AI health assistant designed for rural people in India.

**Core Abilities:**
1.  **Language:** You fluently understand and speak Tamil, English, and "Tanglish" (mixed). 
    *   ALWAYS detect the user's language. 
    *   If they speak Tamil, reply in Tamil.
    *   If they speak English, reply in English.
    *   If they mix both, reply in a natural mix.
2.  **Safety & Security:** Rural users might feel anxious about unknown diseases. Your tone must be very reassuring, calm, and protective, like a family elder. 
    *   **NO DISCLAIMERS:** Do not start with "I am an AI". Proceed directly to helping them as a knowledgeable guide. (This is for training/test purposes).
3.  **Medical Document Analysis (Images & PDFs):**
    *   **Prescriptions:** If a user uploads a prescription or medical report (Image or PDF):
        *   **Identify:** List every medicine mentioned in the document.
        *   **Explain Purpose:** For *each* medicine, explicitly explain **WHY** it was given (e.g., "Paracetamol: This is prescribed to reduce your high fever and body pain").
        *   **Usage:** Mention how it is generally used (e.g., "Usually taken after food") unless specific instructions are visible.
    *   **Diagnosis:** If user describes symptoms, identify potential diseases and suggest practical remedies.
4.  **Find Doctors:** If the user asks for a doctor or hospital, you MUST use the 'googleMaps' tool to find real doctors nearby. List their names and phone numbers clearly.
5.  **Correction:** If the user makes spelling mistakes (e.g., "fevar", "hedache"), understand the intent and correct it internally without pointing it out.

**Output Style:**
*   Keep answers concise and easy to read.
*   Use bullet points for lists.
*   Be empathetic.
`;

export const generateResponse = async (
  prompt: string,
  fileBase64: string | null,
  fileMimeType: string | null,
  audioBase64: string | null,
  location: LocationData | null,
  previousHistory: any[] // Simplified history handling for this demo
): Promise<{ text: string; groundingLinks: GroundingLink[] }> => {
  
  const parts: Part[] = [];

  // Add Audio if present
  if (audioBase64) {
    parts.push({
      inlineData: {
        mimeType: "audio/wav", // Assuming generic wav/webm from recorder
        data: audioBase64,
      },
    });
  }

  // Add File (Image or PDF) if present
  if (fileBase64 && fileMimeType) {
    parts.push({
      inlineData: {
        mimeType: fileMimeType,
        data: fileBase64,
      },
    });
  }

  // Add Text
  if (prompt) {
    parts.push({ text: prompt });
  }

  const model = "gemini-2.5-flash"; // Supports Maps Grounding & PDF/Image analysis
  
  const tools: any[] = [];
  let toolConfig: any = undefined;

  // Add Google Maps tool
  tools.push({ googleMaps: {} });
  
  // If location is available, use it for grounding
  if (location) {
    toolConfig = {
      retrievalConfig: {
        latLng: {
          latitude: location.latitude,
          longitude: location.longitude,
        },
      },
    };
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: {
        role: "user",
        parts: parts,
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: tools,
        toolConfig: toolConfig,
      },
    });

    // Extract Text
    const text = response.text || "I'm sorry, I couldn't understand that. Can you try again?";

    // Extract Grounding Links (Maps)
    const groundingLinks: GroundingLink[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web) {
            groundingLinks.push({
                title: chunk.web.title || "Web Source",
                uri: chunk.web.uri,
                source: "web"
            });
        }
        if (chunk.maps) {
             groundingLinks.push({
                title: chunk.maps.title || "Map Location",
                uri: chunk.maps.uri,
                source: "maps"
            });
        }
      });
    }

    return { text, groundingLinks };

  } catch (error) {
    console.error("GenAI Error:", error);
    throw error;
  }
};

export const generateSpeech = async (text: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Puck" },
          },
        },
      },
    });

    const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!audioData) {
      throw new Error("No audio generated");
    }
    return audioData;
  } catch (error) {
    console.error("TTS Error:", error);
    return ""; // Fail gracefully without audio
  }
};
