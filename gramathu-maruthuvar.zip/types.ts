export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  audioUrl?: string; // For AI spoken response
  fileUrl?: string; // For user uploaded files (Image or PDF)
  fileType?: string; // MIME type (e.g., 'image/jpeg', 'application/pdf')
  fileName?: string; // Name of the uploaded file
  isError?: boolean;
  groundingLinks?: GroundingLink[];
}

export interface GroundingLink {
  title: string;
  uri: string;
  source: string; // 'maps' or 'web'
}

export interface LocationData {
  latitude: number;
  longitude: number;
}

export enum AppState {
  IDLE = 'IDLE',
  LISTENING = 'LISTENING',
  PROCESSING = 'PROCESSING',
  SPEAKING = 'SPEAKING',
}
