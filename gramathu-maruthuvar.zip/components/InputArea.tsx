import React, { useState, useRef } from 'react';
import { PaperAirplaneIcon, MicrophoneIcon, DocumentIcon, StopIcon, PaperClipIcon } from '@heroicons/react/24/solid';

interface InputAreaProps {
  onSend: (text: string, audioBlob: Blob | null, fileBlob: Blob | null, fileName: string | null) => void;
  disabled: boolean;
}

const InputArea: React.FC<InputAreaProps> = ({ onSend, disabled }) => {
  const [text, setText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        onSend('', audioBlob, null, null);
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Microphone access is required for voice features.");
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleSendText = () => {
    if (!text.trim() && !selectedFile) return;
    
    const fileBlob = selectedFile ? selectedFile.slice(0, selectedFile.size, selectedFile.type) : null;
    const fileName = selectedFile ? selectedFile.name : null;

    onSend(text, null, fileBlob, fileName);
    setText('');
    setSelectedFile(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendText();
    }
  };

  return (
    <div className="bg-white border-t border-slate-200 p-4 pb-6 md:pb-4 fixed bottom-0 w-full z-10 max-w-5xl mx-auto left-0 right-0 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
      {/* File Preview */}
      {selectedFile && (
        <div className="mb-2 flex items-center gap-2">
          <div className="relative">
            {selectedFile.type.startsWith('image/') ? (
              <img 
                src={URL.createObjectURL(selectedFile)} 
                alt="Preview" 
                className="h-16 w-16 object-cover rounded-lg border border-slate-300" 
              />
            ) : (
              <div className="h-16 w-16 bg-slate-100 rounded-lg border border-slate-300 flex flex-col items-center justify-center p-1 text-slate-500">
                <DocumentIcon className="w-8 h-8" />
                <span className="text-[10px] truncate w-full text-center">{selectedFile.name.split('.').pop()}</span>
              </div>
            )}
            <button 
              onClick={() => setSelectedFile(null)}
              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs shadow-sm"
            >
              ×
            </button>
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium text-slate-700 truncate max-w-[200px]">{selectedFile.name}</span>
            <span className="text-xs text-slate-500">Attached</span>
          </div>
        </div>
      )}

      <div className="flex items-end gap-2">
        {/* Upload Button */}
        <button 
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled || isRecording}
          className="p-3 text-slate-400 hover:text-teal-600 hover:bg-teal-50 rounded-full transition-colors disabled:opacity-50"
        >
          <PaperClipIcon className="w-6 h-6" />
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          accept="image/*,application/pdf" 
          onChange={handleFileChange}
        />

        {/* Text Input */}
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isRecording ? "Listening..." : "Type, or upload prescription/report..."}
          disabled={disabled || isRecording}
          className="flex-1 bg-slate-100 border-0 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-teal-500 focus:bg-white transition-all resize-none max-h-32 min-h-[50px] tamil-text"
          rows={1}
        />

        {/* Mic / Send Button Toggle */}
        {text.trim() || selectedFile ? (
           <button 
             onClick={handleSendText}
             disabled={disabled}
             className="p-3 bg-teal-600 hover:bg-teal-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:shadow-none"
           >
             <PaperAirplaneIcon className="w-6 h-6" />
           </button>
        ) : (
          <button 
            onClick={isRecording ? handleStopRecording : handleStartRecording}
            disabled={disabled && !isRecording}
            className={`p-3 rounded-full shadow-lg transition-all ${
              isRecording 
                ? 'bg-red-500 hover:bg-red-600 animate-pulse text-white' 
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {isRecording ? <StopIcon className="w-6 h-6" /> : <MicrophoneIcon className="w-6 h-6" />}
          </button>
        )}
      </div>
    </div>
  );
};

export default InputArea;
