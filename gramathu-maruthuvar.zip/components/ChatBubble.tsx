import React, { useState } from 'react';
import { Message } from '../types';
import { PlayIcon, StopIcon, MapPinIcon, UserIcon, DocumentIcon } from '@heroicons/react/24/solid';
import ReactMarkdown from 'react-markdown';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  const handlePlayAudio = () => {
    if (!message.audioUrl) return;

    if (isPlaying && audioElement) {
      audioElement.pause();
      audioElement.currentTime = 0;
      setIsPlaying(false);
    } else {
      const audio = new Audio(message.audioUrl);
      audio.onended = () => setIsPlaying(false);
      audio.play().catch(e => console.error("Playback error", e));
      setAudioElement(audio);
      setIsPlaying(true);
    }
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-[85%] md:max-w-[70%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start gap-2`}>
        
        {/* Avatar */}
        <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isUser ? 'bg-indigo-600' : 'bg-teal-600'}`}>
          {isUser ? (
             <UserIcon className="w-5 h-5 text-white" />
          ) : (
             <span className="text-xl">🩺</span> 
          )}
        </div>

        {/* Bubble */}
        <div className={`p-4 rounded-2xl shadow-sm border ${
          isUser 
            ? 'bg-indigo-50 border-indigo-100 text-slate-800 rounded-tr-none' 
            : 'bg-white border-slate-100 text-slate-800 rounded-tl-none'
        }`}>
          {/* File Attachment */}
          {message.fileUrl && (
            <div className="mb-3">
              {message.fileType?.startsWith('image/') ? (
                <img src={message.fileUrl} alt="Uploaded" className="max-h-48 rounded-lg border border-slate-200 object-cover" />
              ) : (
                <a href={message.fileUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                  <div className="bg-red-100 p-2 rounded-lg">
                    <DocumentIcon className="w-6 h-6 text-red-600" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-slate-900 truncate max-w-[150px]">{message.fileName || "Document"}</span>
                    <span className="text-xs text-slate-500 uppercase">{message.fileType?.split('/')[1] || "FILE"}</span>
                  </div>
                </a>
              )}
            </div>
          )}

          {/* Text Content */}
          <div className="prose prose-sm prose-slate max-w-none tamil-text text-base leading-relaxed">
             <ReactMarkdown>{message.text}</ReactMarkdown>
          </div>

          {/* Grounding Links / Doctor Cards */}
          {message.groundingLinks && message.groundingLinks.length > 0 && (
            <div className="mt-4 flex flex-col gap-2">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">References & Locations</p>
              {message.groundingLinks.map((link, idx) => (
                <a 
                  key={idx} 
                  href={link.uri} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
                >
                  <div className="bg-red-100 p-2 rounded-full">
                    <MapPinIcon className="w-4 h-4 text-red-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">{link.title}</p>
                    <p className="text-xs text-blue-600 truncate">View on Map</p>
                  </div>
                </a>
              ))}
            </div>
          )}

          {/* Audio Controls (AI Only) */}
          {!isUser && message.audioUrl && (
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-2">
              <button 
                onClick={handlePlayAudio}
                className="flex items-center gap-2 px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-700 rounded-full text-sm font-medium transition-colors"
              >
                {isPlaying ? <StopIcon className="w-4 h-4" /> : <PlayIcon className="w-4 h-4" />}
                {isPlaying ? 'Stop' : 'Listen (Tamil/English)'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatBubble;
