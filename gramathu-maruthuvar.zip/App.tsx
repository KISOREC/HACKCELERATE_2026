import React, { useState, useEffect, useRef } from 'react';
import { Message, AppState, LocationData } from './types';
import ChatBubble from './components/ChatBubble';
import InputArea from './components/InputArea';
import { generateResponse, generateSpeech } from './services/geminiService';
import { blobToBase64 } from './services/audioUtils';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [location, setLocation] = useState<LocationData | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial Welcome Message
  useEffect(() => {
    const welcomeMsg: Message = {
      id: 'welcome',
      role: 'model',
      text: "Vanakkam! I am your Gramathu Maruthuvar (Village Doctor). \n\nHow are you feeling? You can upload a **prescription (photo or PDF)** or tell me your symptoms. I will explain why each medicine is given.",
    };
    setMessages([welcomeMsg]);
    
    // Get Location
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error("Location access denied or failed", error);
        }
      );
    }
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (text: string, audioBlob: Blob | null, fileBlob: Blob | null, fileName: string | null) => {
    if (appState === AppState.PROCESSING) return;

    const newMessageId = Date.now().toString();
    
    let displayFileUrl = undefined;
    if (fileBlob) {
        displayFileUrl = URL.createObjectURL(fileBlob);
    }

    const newUserMessage: Message = {
      id: newMessageId,
      role: 'user',
      text: text || (audioBlob ? '🎤 (Voice Message)' : '📄 (File Sent)'),
      fileUrl: displayFileUrl,
      fileType: fileBlob?.type,
      fileName: fileName || 'Document',
    };

    setMessages(prev => [...prev, newUserMessage]);
    setAppState(AppState.PROCESSING);

    try {
      // 1. Prepare Inputs
      let audioBase64: string | null = null;
      let fileBase64: string | null = null;
      let fileMimeType: string | null = null;

      if (audioBlob) {
        audioBase64 = await blobToBase64(audioBlob);
      }
      if (fileBlob) {
        fileBase64 = await blobToBase64(fileBlob);
        fileMimeType = fileBlob.type;
      }

      // 2. Call Gemini for Text Response & Grounding
      const { text: responseText, groundingLinks } = await generateResponse(
        text,
        fileBase64,
        fileMimeType,
        audioBase64,
        location,
        messages
      );

      // 3. Call Gemini TTS for Audio Response
      const audioResponseBase64 = await generateSpeech(responseText);
      const audioUrl = audioResponseBase64 ? `data:audio/mp3;base64,${audioResponseBase64}` : undefined;

      // 4. Update UI
      const newAiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        groundingLinks: groundingLinks,
        audioUrl: audioUrl
      };

      setMessages(prev => [...prev, newAiMessage]);

    } catch (error) {
      console.error("Error in chat loop:", error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: 'model',
        text: "Mannikkavum (Sorry), I am having trouble reading that file or connecting. Please try again.",
        isError: true
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setAppState(AppState.IDLE);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 max-w-5xl mx-auto shadow-2xl overflow-hidden relative">
      
      {/* Header */}
      <header className="bg-teal-700 text-white p-4 shadow-md z-20 flex items-center gap-3">
        <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-teal-700 text-2xl shadow-inner">
           🏥
        </div>
        <div>
          <h1 className="text-xl font-bold font-serif tracking-wide">Gramathu Maruthuvar</h1>
          <p className="text-xs text-teal-100 opacity-90">Your 24/7 Village Health Companion</p>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 pb-32 no-scrollbar">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full opacity-50">
             <div className="text-6xl mb-4">🩺</div>
             <p>Starting...</p>
          </div>
        ) : (
          messages.map((msg) => (
            <ChatBubble key={msg.id} message={msg} />
          ))
        )}
        
        {/* Loading Indicator */}
        {appState === AppState.PROCESSING && (
          <div className="flex justify-start w-full mb-6">
             <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100 flex items-center gap-3">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-teal-500 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-teal-500 rounded-full animate-bounce delay-75"></div>
                  <div className="w-2 h-2 bg-teal-500 rounded-full animate-bounce delay-150"></div>
                </div>
                <span className="text-sm text-slate-500">Reading prescription...</span>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* Input Area */}
      <InputArea onSend={handleSend} disabled={appState === AppState.PROCESSING} />
    </div>
  );
};

export default App;
